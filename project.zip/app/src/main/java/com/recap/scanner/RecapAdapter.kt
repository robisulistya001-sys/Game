package com.recap.scanner

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.recap.scanner.databinding.ItemRecapBinding

class RecapAdapter(private var items: List<RecapEntry>) :
    RecyclerView.Adapter<RecapAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemRecapBinding) : RecyclerView.ViewHolder(binding.root)

    fun updateData(newItems: List<RecapEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRecapBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvResi.text = item.noResi
        holder.binding.tvNama.text = item.nama
        holder.binding.tvRtRw.text = item.rtRw
        holder.binding.tvCod.text = "Rp ${item.codAmount}"
        holder.binding.tvStatus.text = item.statusBayar
        holder.binding.tvWaktu.text = "${item.tanggal} ${item.waktu}"
    }

    override fun getItemCount(): Int = items.size
}
