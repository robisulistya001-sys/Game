package com.recap.scanner

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recap_entries")
data class RecapEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tanggal: String,       // format: yyyy-MM-dd, buat pengelompokan rekap harian
    val waktu: String,         // format: HH:mm:ss, jam tepat waktu scan
    val noResi: String,
    val nama: String,
    val rtRw: String,
    val codAmount: String,     // disimpan sebagai teks (misal "49,857") biar aman kalau format aneh
    val statusBayar: String,
    val rawText: String        // teks OCR mentah, buat jaga-jaga kalau parsing meleset & mau dicek manual
)
