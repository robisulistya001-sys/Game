package com.recap.scanner

/**
 * Parser ini disesuaikan dari contoh tampilan app kurir (kode resi awalan huruf,
 * ada label "COD", "RT xx RW xx", "Belum Bayar/Lunas", dan nominal dengan koma ribuan).
 *
 * CATATAN PENTING: setiap app kurir punya tata letak beda. Kalau hasil parsing meleset,
 * tinggal sesuaikan regex di bawah ini sesuai app yang dipakai. rawText selalu disimpan
 * di database supaya data mentah tidak hilang walau parsing gagal.
 */
object OcrParser {

    private val resiRegex = Regex("""\b([A-Z]{2}\d{8,14})\b""")
    private val rtRwRegex = Regex("""RT\s*\d{1,3}\s*RW\s*\d{1,3}""", RegexOption.IGNORE_CASE)
    private val codNominalRegex = Regex("""\d{1,3}(?:,\d{3})+""")

    data class ParsedResult(
        val noResi: String,
        val nama: String,
        val rtRw: String,
        val codAmount: String,
        val statusBayar: String
    )

    fun parse(rawText: String): ParsedResult {
        val lines = rawText.lines().map { it.trim() }.filter { it.isNotEmpty() }

        // 1. Nomor resi: cari pola 2 huruf besar + digit panjang
        val noResi = resiRegex.find(rawText)?.value ?: "-"

        // 2. RT/RW: cari baris yang mengandung pola "RT xx RW xx"
        val rtRw = rtRwRegex.find(rawText)?.value?.uppercase() ?: "-"

        // 3. Status pembayaran: cari kata kunci umum
        val statusBayar = when {
            rawText.contains("Belum Bayar", ignoreCase = true) -> "Belum Bayar"
            rawText.contains("Lunas", ignoreCase = true) -> "Lunas"
            rawText.contains("Sudah Bayar", ignoreCase = true) -> "Sudah Bayar"
            else -> "-"
        }

        // 4. Nominal COD: ambil angka dengan format ribuan (contoh: 49,857)
        //    Kalau ada beberapa angka (misal COD & Total sama), ambil yang pertama muncul
        //    setelah kata "COD".
        val codAmount = extractCodAmount(lines) ?: "-"

        // 5. Nama pelanggan: heuristik -- biasanya baris besar di dekat atas,
        //    sebelum baris "Total X item". Cari baris tepat sebelum baris yang
        //    mengandung kata "Total" dan "item".
        val nama = extractNama(lines) ?: "-"

        return ParsedResult(noResi, nama, rtRw, codAmount, statusBayar)
    }

    private fun extractCodAmount(lines: List<String>): String? {
        val codLineIndex = lines.indexOfFirst { it.equals("COD", ignoreCase = true) || it.contains("COD", ignoreCase = true) }
        if (codLineIndex != -1) {
            // cari nominal di baris yang sama atau beberapa baris setelahnya
            for (i in codLineIndex until minOf(codLineIndex + 4, lines.size)) {
                val match = codNominalRegex.find(lines[i])
                if (match != null) return match.value
            }
        }
        // fallback: ambil nominal pertama yang ditemukan di seluruh teks
        for (line in lines) {
            val match = codNominalRegex.find(line)
            if (match != null) return match.value
        }
        return null
    }

    private fun extractNama(lines: List<String>): String? {
        val totalIndex = lines.indexOfFirst { it.contains("Total", ignoreCase = true) && it.contains("item", ignoreCase = true) }
        if (totalIndex > 0) {
            return lines[totalIndex - 1]
        }
        // fallback: baris pertama yang bukan angka/simbol dan lumayan panjang
        return lines.firstOrNull { line ->
            line.length in 3..40 && line.any { it.isLetter() } && !line.contains("masuk", ignoreCase = true)
        }
    }
}
