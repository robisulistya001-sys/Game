package com.recap.scanner

import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.recap.scanner.databinding.ActivityRecapListBinding
import kotlinx.coroutines.launch
import java.io.OutputStreamWriter

class RecapListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRecapListBinding
    private lateinit var db: RecapDatabase
    private lateinit var adapter: RecapAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecapListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = RecapDatabase.getInstance(this)
        adapter = RecapAdapter(emptyList())
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.btnExport.setOnClickListener { exportToCsv() }

        loadData()
    }

    private fun loadData() {
        lifecycleScope.launch {
            val entries = db.recapDao().getAll()
            adapter.updateData(entries)
            binding.tvEmpty.visibility = if (entries.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            binding.tvTotal.text = "Total: ${entries.size} data"
        }
    }

    private fun exportToCsv() {
        lifecycleScope.launch {
            val entries = db.recapDao().getAll()
            if (entries.isEmpty()) {
                Toast.makeText(this@RecapListActivity, "Belum ada data untuk di-export", Toast.LENGTH_SHORT).show()
                return@launch
            }

            val fileName = "rekap_scanner_${System.currentTimeMillis()}.csv"
            val sb = StringBuilder()
            sb.append("Tanggal,Waktu,No Resi,Nama,RT/RW,COD,Status Bayar\n")
            for (e in entries) {
                sb.append("\"${e.tanggal}\",\"${e.waktu}\",\"${e.noResi}\",\"${e.nama}\",\"${e.rtRw}\",\"${e.codAmount}\",\"${e.statusBayar}\"\n")
            }

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val resolver = contentResolver
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                        put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/RecapScanner")
                    }
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        resolver.openOutputStream(uri)?.use { out ->
                            OutputStreamWriter(out).use { it.write(sb.toString()) }
                        }
                        Toast.makeText(this@RecapListActivity, "Tersimpan di Download/RecapScanner/$fileName", Toast.LENGTH_LONG).show()
                    }
                } else {
                    val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                    val file = java.io.File(downloadsDir, fileName)
                    file.writeText(sb.toString())
                    Toast.makeText(this@RecapListActivity, "Tersimpan di ${file.absolutePath}", Toast.LENGTH_LONG).show()
                }
            } catch (ex: Exception) {
                Toast.makeText(this@RecapListActivity, "Gagal export: ${ex.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        loadData()
    }
}
