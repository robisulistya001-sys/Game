package com.recap.scanner

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [RecapEntry::class], version = 1, exportSchema = false)
abstract class RecapDatabase : RoomDatabase() {

    abstract fun recapDao(): RecapDao

    companion object {
        @Volatile
        private var INSTANCE: RecapDatabase? = null

        fun getInstance(context: Context): RecapDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RecapDatabase::class.java,
                    "recap_scanner.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
