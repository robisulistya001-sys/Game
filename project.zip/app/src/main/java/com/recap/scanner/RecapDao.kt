package com.recap.scanner

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface RecapDao {

    @Insert
    suspend fun insert(entry: RecapEntry): Long

    @Query("SELECT * FROM recap_entries ORDER BY id DESC")
    suspend fun getAll(): List<RecapEntry>

    @Query("SELECT * FROM recap_entries WHERE tanggal = :tanggal ORDER BY id DESC")
    suspend fun getByDate(tanggal: String): List<RecapEntry>

    @Query("DELETE FROM recap_entries WHERE id = :id")
    suspend fun deleteById(id: Long)
}
